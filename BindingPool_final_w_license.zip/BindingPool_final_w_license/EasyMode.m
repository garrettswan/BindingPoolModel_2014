function varargout = EasyMode(varargin)

%    This file is part of EasyMode.
%
%    EasyMode is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    EasyMode is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with EasyMode.  If not, see <http://www.gnu.org/licenses/>.

%% EASYMODE MATLAB code for EasyMode.fig
%      EASYMODE, by itself, creates a new EASYMODE or raises the existing
%      singleton*.
%
%      H = EASYMODE returns the handle to a new EASYMODE or the handle to
%      the existing singleton*.
%
%      EASYMODE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EASYMODE.M with the given input arguments.
%
%      EASYMODE('Property','Value',...) creates a new EASYMODE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before EasyMode_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to EasyMode_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help EasyMode

% Last Modified by GUIDE v2.5 08-Jan-2014 14:49:09

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @EasyMode_OpeningFcn, ...
    'gui_OutputFcn',  @EasyMode_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
end

% --- Executes just before EasyMode is made visible.
function EasyMode_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to EasyMode (see VARARGIN)

% Choose default command line output for EasyMode
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes EasyMode wait for user response (see UIRESUME)
% uiwait(handles.figure1);
end

% --- Outputs from this function are returned to the command line.
function varargout = EasyMode_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
end

% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2


str = get(hObject, 'String');
val = get(hObject,'Value');
% Set current data to the selected data set.

handles.current_data.task = [0 0 0 0 0 0 0 0 0 0];

switch str{val};
    case 'Change detection'
        handles.current_data.task = [0 1 0 0 0 0 0 0 0 0];
    case 'Continuous report '
        handles.current_data.task = [1 0 0 0 0 0 0 0 0 0];
    case 'Confidence of continuous report'
        handles.current_data.task = [0 0 0 1 0 0 0 0 0 0];
    case 'Similarity'
        handles.current_data.task = [0 0 1 0 0 0 0 0 0 0];
    case 'Magnet simulation'
        handles.current_data.task = [0 0 0 0 1 0 0 0 0 0];
    case 'Magnet prediction'
        handles.current_data.task = [0 0 0 0 0 1 0 0 0 0];
    case 'Directed forgetting'
        handles.current_data.task = [0 0 0 0 0 0 1 0 0 0];
    case 'High v low similarity'
        handles.current_data.task = [0 0 0 0 0 0 0 1 0 0];
end
% Save the handles structure.

guidata(hObject,handles)

end

% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double

handles.current_data.trialcount = get(hObject,'String');
guidata(hObject,handles)

end

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% try
%     trialcount = str2num(handles.current_data.trialcount);
% catch
%     trialcount = 1000;
% end

task = [1 1 1 1 1 1 1 1 1 1];



a{1} = '*************************************************';
a{2} = '                            ';
a{3} = ' Currently simulating';
a{4}= ' ';
a{5}= '**************************************************';

h = msgbox(a);
set(findobj(h,'style','pushbutton'),'Visible','off')

RunAPP_data(str2num(get(handles.edit1,'String')),task,str2num(get(handles.edit2,'String')));


close(h)
close EasyMode
end

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% try
%     trialcount = str2num(handles.current_data.trialcount);
% catch
%     trialcount = 1000;
% end

try
    handles.current_data.task;
catch
    close EasyMode
    '****************************************'
    '****************************************'
    '****************************************'
    'ERROR'
    'It looks like you didn''t select a task.'
    '****************************************'
    keyboard
end

% try
%     trialcount = str2num(handles.current_data.trialcount);
% catch
%     trialcount = 1000;
% end


a{1} = '*************************************************';
a{2} = '                            ';
a{3} = ' Currently simulating';
a{4}= ' ';
a{5}= '**************************************************';

h = msgbox(a);
set(findobj(h,'style','pushbutton'),'Visible','off')

RunAPP_data(str2num(get(handles.edit1,'String')),handles.current_data.task,str2num(get(handles.edit2,'String')));

close(h)
clear forgui
close EasyMode

end

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


close EasyMode

end

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%close EasyMode

a{1} = '*************************************************';
a{2} = '                       HELP           ';
a{3} = ' ';
a{4} = 'Here are brief descriptions of the tasks that you';
a{5} = 'can simulate with this GUI: ';
a{6} = ' ';
a{7} = '1. Change detection task - whole display, set';
a{8} = 'sizes 2, 4, 6, 8';
a{9} = ' ';
a{10} = '2. Continuous report task - set sizes 1, 2, 4';
a{11}= '6';
a{12}= ' ';
a{13}= '3. Confidence of continuous report - continuous';
a{14}= 'report binned by different confidence levels';
a{15}= ' ';
a{16}= '4. Similarity - continuous report with varying';
a{17}= 'levels of proximity for the presented items';
a{18}= ' ';
a{19}= '5. Magnet simulation - continuous report that';
a{20}= 'demonstrates one item pulling another';
a{21}= ' ';
a{22}= '6. Magnet prediction - continuous report that';
a{23}= 'demonstrates two items pulling another';
a{24}= ' ';
a{25}= '7. Directed forgetting - continuous report with';
a{26}= 'one item being cued to forget';
a{27}= ' ';
a{28}= '8. High v low similarity - change detection that';
a{29}= 'that demonstrates how proximity affects precision';
a{30}= ' ';
a{31}= '**************************************************';


h = msgbox(a);
set(findobj(h,'style','pushbutton'),'Visible','off')

end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double

end


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end
