%% This function checks the conjoining connections between the Type layer
% and the Token layer, then it summates the activation value for every
% Binding pool node connected to a specific type. This total value becomes
% the activation for that specific type node.


function [representation representation_2] = Retrieve(model,parameter,token,type_2_feature)


representation = zeros(parameter.type_size,1);
representation_2 = zeros(parameter.type_2_size,1);

a = 0;
b = 0;

type2_layer = zeros(1,parameter.type_2_size);

if parameter.no_type_cue == 1
    type2_layer = type2_layer + 1;
else
    type2_layer(type_2_feature) = 1;
end



if token ~= 0
    
    tokens = zeros(1,parameter.token);
    tokens(token) = 1;
    
    representation = (type2_layer * model.type_2_weight) .* (tokens*model.token_weight).*model.bpnodes * model.type_weight';
end

% for bpnode = 1:parameter.bp_size
%     
%     if(token > 0)
%         tokweight = model.token_weight(token,bpnode);
%     end
%     
%     if token ==0 | tokweight %if there is a connection between this token and this BP node
%            
%         if(type_2_feature == 0)   %if no type_2 is specified, retrieve based on token only
%            for type = 1:parameter.type_size   %retrieve type based on token
%                 a = model.bpnodes(bpnode) * model.type_weight(type,bpnode);
%                 representation(type) = representation(type) + a;
%            end
%            for type = 1:parameter.type_2_size   %retrieve type based on token
%                 a = model.bpnodes(bpnode) * model.type_2_weight(type,bpnode);
%                 representation_2(type) = representation_2(type) + a;
%              end
%         else %retrieve type1 based on token AND type2
%                      
%            
%           %extract the weight value from type_2 to this one
%     
%             for type = 1:parameter.type_size
%                 a = model.bpnodes(bpnode)* model.type_weight(type,bpnode) * model.type_2_weight(type_2_feature,bpnode);
%                 representation(type) = representation(type) + a;
%             end
%         
%         end
%     end
% end

end



