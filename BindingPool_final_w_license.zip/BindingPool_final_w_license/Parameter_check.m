function Parameter_check(parameter)

%    This file is part of Parameter_check.
%
%    Parameter_check is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Parameter_check is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with Parameter_check.  If not, see <http://www.gnu.org/licenses/>.

%% This function does some preliminary checks to prevent the model crashing
%% from an incorrect input design.

% This list is no finished!

if sum([parameter.continuous_report parameter.change_detection]) > 1
    '***************ERRROR*****************'
    'You seem to have activated multiple task types'
    'In the function setParameters.m, choose either continuous report or change detection'
    keyboard
elseif length(parameter.changed_items) == length([min(parameter.setsize):max(parameter.setsize)]) && parameter.change_detection
    '***************ERRROR*****************'
    'The changed item parameter is not properly indexed with the set size.'
    'In the function setParameter.m, refer to the comments to fix this parameter'
    keyboard
elseif length(parameter.probe_items) == length([min(parameter.setsize):max(parameter.setsize)]) && parameter.change_detection
    '***************ERRROR*****************'
    'The display item parameter is not properly indexed with the set size.'
    'In the function setParameter.m, refer to the comments to fix this parameter'
    keyboard
elseif min(parameter.setsize) == 0
    '***************ERRROR*****************'
    'It looks like set size is equal to zero.'
    'In the function setParameter.m, refer to the comments to fix this parameter'
    keyboard
elseif min(parameter.bp_size) == 0
    '***************ERRROR*****************'
    'It looks like the binding pool size is equal to zero, you big dumby.'
    'In the function setParameter.m, refer to the comments to fix this parameter'
    keyboard
elseif parameter.binding_items == 1 && sum(isnan((parameter.changed_items -1)./0)) > 1
    '***************ERRROR*****************'
    'Binding Items is on but the # of changed items is not correct'
    
    keyboard
elseif parameter.binding_items == 1 && isnan(parameter.changed_items(1)/0) ~= 0
    '***************ERRROR*****************'
    'Binding Items is on but the # of changed items is  1'

    keyboard
elseif min(parameter.trialcount) == 0
    '***************ERRROR*****************'
    
    keyboard
    
elseif sum([parameter.confidence parameter.change_detection]) > 1
    '***************ERRROR*****************'
    'Looks like you are trying to run confidence with either change detection'
    'Currently, confidence is only functual for continuous report'
    keyboard
    
elseif parameter.binding_items && parameter.fixed_item_space == 0
    '***************ERRROR*****************'
    'Looks like you are trying to run binding without fixed item space turned on'
    keyboard
% elseif parameter.confidence == 1 && parameter.plot_retrieved_location == 0
%     '***************ERRROR*****************'
%     'Looks like you need to turn on parameter.plot_retrieved_location'
%     keyboard

end

