function Model_sim = BaysModel(trial_data,parameter,load,Model_sim)

%    This file is part of BaysModel.
%
%    BaysModel is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    BaysModel is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with BaysModel.  If not, see <http://www.gnu.org/licenses/>.

%% This function passes the model's retrieved values into a mixture model
% in Bays et al. (2009).


% Picking the cued item

if parameter.fixed_target_item == 0
    target_item = randi(load,[1 parameter.trialcount]);
else
    target_item = zeros(1,parameter.trialcount)+parameter.fixed_target_item;
end


% If confidence is on...
if parameter.confidence
    
    for confidence_category = 1:3
        
        x = [];
        nt = [];
        t = [];
        
        conf_strength = [];
        
        count = 0;
        
        % These are the confidence bins
        if confidence_category == 1
            consplit_min = 0;
            consplit_max = parameter.consplit_tertile1;
        elseif confidence_category == 2
            consplit_min = parameter.consplit_tertile1;
            consplit_max = parameter.consplit_tertile2;
        else
            consplit_min = parameter.consplit_tertile2;
            consplit_max = 10000;
        end
        
        % Organizing the proper input into the mixture model
        for trial = 1:(parameter.trialcount)
            
            retrieved_length = trial_data(trial,target_item(trial)).retrieved_length;
            
            if retrieved_length < consplit_max && retrieved_length > consplit_min
                count = count + 1;
                
                % Actual retrieved location
                x(count) =  trial_data(trial,target_item(trial)).retrieved_location;
                
                % Non-target locations
                if load > 1
                    nt(:,count) = trial_data(trial,target_item(trial)).nontarget_radians;
                end
                
                % Original target location
                t(count) = trial_data(trial,target_item(trial)).target_radians;
                
                %       Mixmod_data.CDA(trials) =
                %       trial_data(trials,target_item(trials)).CDA;
            end
        end
        
        % Run this through the mixture model
        
        if isempty(x) == 0
            if load > 1
                output = JV10_fit(x',t',nt');
            elseif load == 1
                output = JV10_fit(x',t');
            end
        else
            output = [0 0 0 0];
        end
        
        Model_sim(load).correct_identification(confidence_category) =  output(2);
        Model_sim(load).deviation(confidence_category) = rad2deg(sqrt(1/output(1)));
        Model_sim(load).prob_distractor(confidence_category) = output(3);
        Model_sim(load).prob_guessing(confidence_category) = output(4);
        
    end
else % Confidence is not activated.
    
    for trial = 1:(parameter.trialcount)
        
        x(trial) =  trial_data(trial,target_item(trial)).retrieved_location;
        
        if load > 1
            nt(:,trial) = trial_data(trial,target_item(trial)).nontarget_radians;
        end
        
        t(trial) = trial_data(trial,target_item(trial)).target_radians;
        
    end
    
    if load > 1
        output = JV10_fit(x',t',nt');
    else
        output = JV10_fit(x',t');
    end
    
    Model_sim(load).correct_identification = output(2);
    Model_sim(load).deviation = rad2deg(sqrt(1/output(1)));
    Model_sim(load).prob_distractor = output(3);
    Model_sim(load).prob_guessing = output(4);
    
end
end

