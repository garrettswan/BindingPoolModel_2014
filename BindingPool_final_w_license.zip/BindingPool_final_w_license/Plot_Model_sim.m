function Plot_Model_sim(Model_sim,parameter,cd_sim)

%    This file is part of Plot_Model_sim.
%
%    Plot_Model_sim is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Plot_Model_sim is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with Plot_Model_sim.  If not, see
%    <http://www.gnu.org/licenses/>.

%% This function is specifically for plotting the model simulations
%

addpath Functions

if parameter.continuous_report


    % bays 2009 stimulus duration = 100ms
    bays_sd = [14.5 19.2 23.7 24.7];
    bays_g = [.02 .065 .22 .215];
    bays_b = [0  .04  .11   .31];

    bays_x = [1 2 4 6];

    % bays 2009 stimulus duration = 100ms
    bays_sd_error = [.5 .75 1 2];
    bays_b_error = [0 .005 .03 .045];
    bays_g_error = [.001 .02 .05 .055];

    if parameter.confidence

        figure('OuterPosition',[100 300 1000 600])
        hold on

        for confidence = 1:3

            sd = [];
            b = [];
            g = [];
            count = 0;

            for i = parameter.setsize

                count = count +1;
                sd(count) = Model_sim(i).deviation(confidence);
                b(count) = Model_sim(i).prob_distractor(confidence);
                g(count) = Model_sim(i).prob_guessing(confidence);

            end

            switch confidence
                case 1
                    color = [1 0 0];
                case 2
                    color = [0 1 0];
                case 3
                    color = [0 0 1];

            end
            subplot(1,3,1)
            plot(parameter.setsize,sd,'--ko','LineWidth',2,'Color',color);
            hold on

            ylim([0 50]);
            xlim([0 7]);

            subplot(1,3,2)
            plot(parameter.setsize,b,'--ko','LineWidth',2,'Color',color);
            hold on

            ylim([0 .50]);
            xlim([0 7]);

            subplot(1,3,3)
            plot(parameter.setsize,g,'--ko','LineWidth',2,'Color',color);
            hold on
            ylim([0 .50]);
            xlim([0 7]);

            if confidence
                legend('Low','Medium','High');
            end
        end
    else

        figure('OuterPosition',[100 300 1000 600])
        hold on

        count = 0;
        for i = parameter.setsize

            count = count +1;
            sd(count) = Model_sim(i).deviation;
            b(count) = Model_sim(i).prob_distractor;
            g(count) = Model_sim(i).prob_guessing;

        end

    end

    if parameter.confidence
        return
    end

    subplot(1,4,1)
    plot(parameter.setsize,sd,'-bo','LineWidth',2);
    hold on
    plot(bays_x,bays_sd,'-ko','LineWidth',2);
    hold on
    ylim([0 50]);
    title('Precision Error','FontSize',16,'FontWeight','Bold');
    xlabel('Set Size','FontSize',14,'FontWeight','Bold');
    ylabel('Standard Deviation','FontSize',14,'FontWeight','Bold')
    legend('Model','Bays et al. 2009','Location','SouthEast')
    xlim([0 7]);

    e_1 = errorbar(bays_x,bays_sd,bays_sd_error,'LineWidth',2,'Color',[0 0 0]);
    errorbar_tick(e_1,20);

    subplot(1,4,2)
    plot(parameter.setsize,b,'-bo','LineWidth',2);
    hold on
    plot(bays_x,bays_b,'-ko','LineWidth',2);
    hold on
    ylim([0 .8]);
    xlabel('Set Size','FontSize',14,'FontWeight','Bold');
    title('Retrieval Errors','FontSize',16,'FontWeight','Bold');
    ylabel('Proportion','FontSize',14,'FontWeight','Bold');
    xlim([0 7]);

    e_3 = errorbar(bays_x,bays_b,bays_b_error,'LineWidth',2,'Color',[0 0 0]);
    errorbar_tick(e_3,20);

    subplot(1,4,3)
    plot(parameter.setsize,g,'-bo','LineWidth',2);
    hold on
    plot(bays_x,bays_g,'-ko','LineWidth',2);
    hold on
    ylim([0 .8]);
    xlabel('Set Size','FontSize',14,'FontWeight','Bold');
    ylabel('Proportion','FontSize',14,'FontWeight','Bold');
    title('Guessing Errors','FontSize',16,'FontWeight','Bold');
    xlim([0 7]);

    legend('Model sim','Bays et al (2009)');

    e_4 = errorbar(bays_x,bays_g,bays_g_error,'LineWidth',2,'Color',[0 0 0]);
    errorbar_tick(e_4,20);

    subplot(1,4,4)
    axis off

    y_loc = .8;
    %uicontrol('Style','text','Units','normalized','BackgroundColor',[1 1 1],'Position',[.75 .1 .8 .8]);
    uicontrol('Style','text','String','PARAMETERS','Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['trial count = ' num2str(parameter.trialcount)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['binding pool size = ' num2str(parameter.bp_size)],'Units','normalized','Position',[.75 y_loc .25 .05]);
   % y_loc = y_loc - .05;
    %     uicontrol('Style','text','String',['capacity = Uniform ( ' [num2str(parameter.capacitybottom)] [num2str(parameter.capacitytop)] ']','Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['proportion of token connectivity = ' num2str(parameter.token_conn)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['sd rmse = ' num2str(parameter.sd_rmse)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['g rmse = ' num2str(parameter.g_rmse)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['b rmse = ' num2str(parameter.b_rmse)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['type overlap = ' num2str(parameter.type_1_overlap)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['token individuation threshold = ' num2str(parameter.token_individuation_threshold)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['token conn = ' num2str(parameter.token_conn)],'Units','normalized','Position',[.75 y_loc .25 .05]);
elseif parameter.change_detection

    count = 0;



        for i = parameter.setsize

            count = count +1;
            c(count) = (1-Model_sim(i).miss);
            f(count) = Model_sim(i).false_alarm;

        end

    figure
    hold on

    Keshvari_hit =                [.79   .63    .55    .5];
    Keshvari_false_alarm =        [.1    .22    .28     .34];

    Keshvari_x = [2 4 6 8];

    Keshvari_hit_error = [.01 .02 .005 .02];
    Keshvari_false_alarm_error = [.015 .01 .01 .02];

    subplot(1,2,1)
    plot(parameter.setsize,c,'LineWidth',2,'Color',[1 0 0])
    hold on
    plot(parameter.setsize,f,'LineWidth',2,'Color',[0 1 0])
    hold on
    plot(Keshvari_x,Keshvari_hit,'LineWidth',2,'Color',[1 0 0],'LineStyle','--')
    hold on
    plot(Keshvari_x,Keshvari_false_alarm,'LineWidth',2,'Color',[0 1 0],'LineStyle','--')
    hold on
    legend('Hit Rate','False alarms','Keshvari''s Hit Rate','Kesvari''s False alarms');
    ylabel('Accuracy','FontSize',14)
    xlabel('Set Size','FontSize',14)
    ylim([0 1])

    legend('Model hit','Model false alarm','Keshvari et al (2013) hit','Keshvari et al (2013) false alarm');

    e_3 = errorbar(Keshvari_x,Keshvari_hit,Keshvari_hit_error,'LineWidth',2,'Color',[1 0 0],'LineStyle','--');
    errorbar_tick(e_3,20);
    hold on

    e_4 = errorbar(Keshvari_x,Keshvari_false_alarm,Keshvari_false_alarm_error,'LineWidth',2,'Color',[0 1 0],'LineStyle','--');
    errorbar_tick(e_4,20);

    subplot(1,2,2)
    axis off

    y_loc = .8;
    %uicontrol('Style','text','Units','normalized','BackgroundColor',[1 1 1],'Position',[.75 .1 .8 .8]);
    uicontrol('Style','text','String','PARAMETERS','Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['trial count = ' num2str(parameter.trialcount)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['binding pool size = ' num2str(parameter.bp_size)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['is binding on? = ' num2str(parameter.binding_items)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    % y_loc = y_loc - .05;
    %  uicontrol('Style','text','String',['capacity = Uniform ( ' [num2str(parameter.capacity)] ' )'],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['proportion of token connectivity = ' num2str(parameter.token_conn)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['length threshold = ' num2str(parameter.length_threshold)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['length variable threshold = ' num2str(parameter.length_threshold_variable)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['deviation threshold = ' num2str(parameter.deviation_threshold)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['deviation variable threshold = ' num2str(parameter.deviation_threshold_variable)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['hit rmse = ' num2str(parameter.hit_rmse)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['fa rmse = ' num2str(parameter.fa_rmse)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['cd rmse = ' num2str(parameter.cd_rmse)],'Units','normalized','Position',[.75 y_loc .25 .05]);
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['token individuation threshold = ' num2str(parameter.token_individuation_threshold)],'Units','normalized','Position',[.75 y_loc .25 .05]);

    if (range(parameter.probe_items) == (min(parameter.setsize)-max(parameter.setsize)))
        y_loc = y_loc - .05;
        uicontrol('Style','text','String','Whole Display','Units','normalized','Position',[.75 y_loc .25 .05]);
    elseif (range(parameter.probe_items) == 0)
        y_loc = y_loc - .05;
        uicontrol('Style','text','String','Single Display','Units','normalized','Position',[.75 y_loc .25 .05]);
    end

    if (range(parameter.changed_items) == 1)
        y_loc = y_loc - .05;
        uicontrol('Style','text','String','2 changes','Units','normalized','Position',[.75 y_loc .25 .05]);
    elseif (range(parameter.changed_items) == 0)
        y_loc = y_loc - .05;
        uicontrol('Style','text','String','1 change','Units','normalized','Position',[.75 y_loc .25 .05]);
    end
    y_loc = y_loc - .05;
    uicontrol('Style','text','String',['is fixed item space on? = ' num2str(parameter.fixed_item_space)],'Units','normalized','Position',[.75 y_loc .25 .05]);

end

if (max(parameter.changed_items) == 1) && parameter.change_detection
    figure
    count = 0;
    for setsize = parameter.setsize
        count = count +1;

        color = [count*.2 count*.2 count*.2];

        
        plot(0:1:(cd_sim.bins-1),cd_sim.proportions_of_change(count,:),'LineWidth',2,'Color',color);
        kesh = cd_sim.proportions_of_change;

        hold on
    end
    legend('Set size 2','4','6','8');

end

end