function model = Storage(model,type_input,parameter,stimulicount,type_2_input)

%    This file is part of Storage.
%
%    Storage is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Storage is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with Storage.  If not, see
%    <http://www.gnu.org/licenses/>.

%% If there is a conjoining connection between the Type layer and the Token
% layer, then a value of 1 is added to that specific Binding pool node.

tokens = zeros(1,parameter.token);

tokens(stimulicount) = 1;

% a = (type_input*model.type_weight);
% b = (type_2_input'*model.type_2_weight);
% c = (tokens * model.token_weight);

if parameter.type_layer_2_status == 0
    model.bpnodes = model.bpnodes + (type_input*model.type_weight).*(tokens * model.token_weight);
else
    model.bpnodes = model.bpnodes + (type_input*model.type_weight).*(type_2_input'*model.type_2_weight).*(tokens * model.token_weight);
end

%type_input .* model.type_weight(:,bpnodelength)'

% 
% 
% 
% 
% for bpnodelength = 1:parameter.bp_size
%     
%     b = 0;
%     a = 0;
% 
%     % Is there a connection?
%     if model.token_weight(stimulicount,bpnodelength) == 1
%         
%         a = type_input .* model.type_weight(:,bpnodelength)';
%         b = type_2_input .* model.type_2_weight(:,bpnodelength);
% 
%         c = sum(a)*sum(b);
%         
%         % Increase binding pool node activity by their multiplication
%         model.bpnodes(bpnodelength) = model.bpnodes(bpnodelength) + c;
%         
%     end
% end

end
