function Plot_retrieved_types(Model_sim,parameter)

figure

types = 1:parameter.type_size;

count = 0;
index = 0;


nt_count = 0;
np_count = 0;

if parameter.normalize_bp == 0
    
    x_lim = [40 450];
    y_lim = [0 .2];
    
    bin_min = 1;
    bin_interval = 4;
    bin_max = 600;
    
else
    x_lim = [0 1];
    y_lim = [0 .2];
    
    bin_min = 0;
    bin_interval = .01;
    bin_max = 1;
end



for load = parameter.setsize
    
    index = index + 1;
    
    for trial = 1:parameter.trialcount
        
        for item = 1:load
            
            
            count = count + 1;
            
            presented_nodes = Model_sim(load).trial_datastore.data(trial,item).presented_items/36;
            
            presented_nodes = presented_nodes + 1;
            
            for node = 1:length(presented_nodes)
                
                if presented_nodes(node) > 10
                    presented_nodes(node) = 1;
                    
                end
            end
            
            target_node = presented_nodes(Model_sim(load).trial_datastore.data(trial,item).targets);
            
            nontarget_node = presented_nodes(presented_nodes~=target_node);
            
            grr = 0;
            
            for i = 1:length(presented_nodes)
                
                a(:,i) = types~=presented_nodes(i);
                
            end
            
            a = sum(a,2);
            
            for j = 1:length(a)
                
                if a(j) == max(a)
                    
                    grr = grr + 1;
                    nonpresented_node(grr) = j;
                    
                end
            end
            
            
            typesused = zeros(length(types),1);
            for(type = types)  %step through all of the types
                if(max(type ==presented_nodes) ==1)
                    typesused(type) = 1;
                end
            end
            
            unusedtypes = find(typesused ==0);
            nonpresented_node = unusedtypes;
            
            %   nonpresented_node
            %   unusedtypes
            
            
            
            
            t(count) = Model_sim(load).trial_datastore.data(trial,item).representation(target_node);
            
            for nts = 1:length(nontarget_node)
                
                nt_count = nt_count + 1;
                
                nt(nt_count) = Model_sim(load).trial_datastore.data(trial,item).representation(nontarget_node(nts));
                
                
            end
            
            for nps = 1:length(nonpresented_node)
                
                np_count = np_count + 1;
                
                np(np_count) = Model_sim(load).trial_datastore.data(trial,item).representation(nonpresented_node(nps));
                
                
            end
            
        end
    end
    
    subplot(length(unique(parameter.setsize)),1,index)
    hold on
    
    [t_y t_x] = hist(t,[bin_min:bin_interval:bin_max]);
    [np_y np_x] = hist(np,[bin_min:bin_interval:bin_max]);
    
    t_y = t_y/sum(t_y);
    np_y = np_y/sum(np_y);
    
    %     load
    
    if load ~= 1
        [nt_y nt_x] = hist(nt,[bin_min:bin_interval:bin_max]);
        nt_y = nt_y/sum(nt_y);
        
                 offtarget_mean = mean(nt)
                 offtarget_std = std(nt)
        
    end
    %
         ontarget_mean = mean(t)
         ontarget_std = std(t)
    %
         nontarget_mean = mean(np)
         nontarget_std = std(np)
    %
    
    
    
    
    plot(t_x,t_y,'Color',[1 0 0], 'LineWidth',2);
    xlim(x_lim)
    ylim(y_lim)
    
    if load ~= 1
        plot(nt_x,nt_y,'Color',[0 1 0], 'LineWidth',2);
    end
    xlim(x_lim)
    ylim(y_lim)
    
    plot(np_x,np_y,'Color',[0 0 1], 'LineWidth',2);
    xlim(x_lim)
    ylim(y_lim)
    
    if load == max(parameter.setsize)
        
        legend('On-Target','Off-Target','Non-presented');
        
    end
    
    t_y = [];
    t_x = [];
    np_y = [];
    np_x = [];
    nt_y = [];
    nt_x = [];
    
    t = [];
    nt = [];
    np = [];
    
    count = 0;
    
    nt_count = 0;
    np_count = 0;
    
    
    
end



end

