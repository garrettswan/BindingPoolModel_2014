function parameter = Feature_space(parameter,already_selected_item_ranges)

%    This file is part of Feature_space.
%
%    Feature_space is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Feature_space is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with Feature_space.  If not, see <http://www.gnu.org/licenses/>.

%% This function sets up the possible values for input
if already_selected_item_ranges(1) == 0
    count = 0;
    for i = parameter.setsize
        count = count + 1;
        for j = 1:parameter.setsize(count)

            if parameter.plot_retrieved_types == 0  && parameter.reduced_variance ==0
                parameter.item_feature_range{i,j} = 1:parameter.sensory_space;
            elseif parameter.plot_retrieved_types == 1 && parameter.reduced_variance ==0
                parameter.item_feature_range{i,j} = [1:10]*36;
            elseif parameter.reduced_variance
                parameter.item_feature_range{i,j} = 1:2 * parameter.reduced_variance_size;
            end
        end
    end
end

if already_selected_item_ranges(2) == 0
    count = 0;
    for i = parameter.setsize
        count = count + 1;
        for j = 1:parameter.setsize(count)
            parameter.changed_item_feature_range{i,j} = 1:parameter.sensory_space;
        end
    end
end


end

