%% This function initalizes the model for a predetermined trial count at
% various set sizes.

function [Model_data parameter] = RunModel(inputparams,task,setsizeparam,model_data)

% jv10 is the subfolder with a mixture model (Bays, et al. 2009) for
% analyzing continuous data as a function of precision, guess rate, and
% swap (or retrieval) errors
addpath 'Functions'
addpath 'jv10'

parameter = setParameters;

% If there isn't an arguement for setsize, then the model will just run the
% default
if(nargin > 2)
    parameter.setsize = setsizeparam;
end


% If there isn't an arguement for the task list, the model will run through
% a whole display change detection task and a continuous report task.
if nargin < 2
    task = 0;
end

% Task 1 is a continuous report task. The set size is currently fixed
% at 1, 2, 4, and 6 to simulate data from Bays et al. 2009
if task == 1
    parameter.continuous_report = 1;
    parameter.change_detection = 0;
    
    
    % Task 2 is a whole display change detection task. The set size is
    % currently fixed at 2, 4, 6, and 8 to simulate data from Keshvari et
    % al. 2013
elseif task == 2
    parameter.continuous_report = 0;
    parameter.change_detection = 1;
end


already_selected_item_ranges = [0 0];

if(nargin > 0)
    
    paramsize = size(inputparams,1);
    
    for i = 1:paramsize
        
        try
            if iscell(inputparams{i,2})
                
                
                
                if strcmp(inputparams{i,1},'parameter.item_feature_range')
                    parameter.item_feature_range = inputparams{i,2};
                    already_selected_item_ranges(1) = 1;
                    
                elseif strcmp(inputparams{i,1},'parameter.changed_item_feature_range')
                    parameter.changed_item_feature_range = inputparams{i,2};
                    already_selected_item_ranges(2) = 1;
                end
                
            elseif size(inputparams{i,2},1) > 1
                
                command = sprintf('%s = [%s];',inputparams{i,1},num2str(inputparams{i,2}'));
                eval(command);
                
            elseif size(inputparams{i,2},2) > 1
                
                command = sprintf('%s = [%s];',inputparams{i,1},num2str(inputparams{i,2}));
                eval(command);
                
            elseif isempty(inputparams{i,2})
                
            else
                command = sprintf('%s = [%s];',inputparams{i,1},num2str(inputparams{i,2}));
                eval(command);
            end
        catch
            keyboard
        end
    end
end

parameter = Feature_space(parameter,already_selected_item_ranges);

% This function will check to see if there are any issues with the set of
% parameters
Parameter_check(parameter)

count = 0;
% This for loop will cycle through the set sizes

%model = Setupconn(parameter);


for load = parameter.setsize
    clear trial_data;
    
    % This for loop intializes the trials
    for trial = 1:parameter.trialcount
        
        
        if parameter.new_setupconn == 1
            model = Setupconn(parameter);
        else
            if mod(trial,parameter.new_setupconn) == 1;
                model = Setupconn(parameter);
            end
        end
        
        
        
        % This function initiates the model
        
        trial_data(trial,1:load) = Model(parameter,load,model);
        
        abort = 0;
        if parameter.progress_bar
            count = count + 1;
            guistuff.whichtrial = count;
            guistuff.totaltrials = size(parameter.setsize,2)*parameter.trialcount;
            abort = Progress_bar(guistuff);
        end
        
        if abort
            return
        end
    end
    
    trial_datastore(load).data = trial_data;
    
    %
    % Change detection analysis, part 1 (i.e. organizing the data to
    % be analyzed in the function Variable_threshold.m
    
    if parameter.change_detection
        Model_sim(load) = CD_Probe_display(trial_datastore(load).data,parameter,load);
    end
    
end



for load = 1:max(parameter.setsize)
    Model_sim(load).trial_datastore = trial_datastore(load);
end

if parameter.plot_retrieved_types;
    Plot_retrieved_types(Model_sim,parameter);
end

if parameter.plot_hists
    Plot_deviations(Model_sim,parameter);
end


Model_data.Model_sim = Model_sim;

end

