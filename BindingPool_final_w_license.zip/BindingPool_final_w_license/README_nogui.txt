
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Binding Pool model
by Garrett Swan and Brad Wyble
January 13th 2013

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Welcome to the Binding Pool model of visual working memory. The purpose of this README_nogui.txt is to 
guide you through the steps required to simulate a variety of visual working memory tasks without using a GUI.

Step one.
Edit RunAPP_data.m

Step two.
Determine how many trials and the number of pseudo-subjects you would like to simulate by adjusting the variables,
trialcount and totalsubjects.

Step three.
Determine whether you would like to run all simulations at once or just a single simulation by setting the simulations
you want to run to the value '1' and the simulations you do not want to run to '0'

Descriptions for the simulations are provided in the comments of RunAPP_data.m

Step four.
Once you have set these parameters, run RunAPP_data.m.

Thanks for your interest in the Binding Pool model.

For further information, please send an email to either gsp.swan@gmail.com or
bwyble@gmail.com

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Garrett Swan and Brad Wyble