% Converts radians to degrees
function d = rad2deg(r)
  d = (180/pi) * r;
end