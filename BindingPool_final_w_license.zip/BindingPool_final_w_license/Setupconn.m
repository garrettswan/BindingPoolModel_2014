function model = Setupconn(parameter)

%    This file is part of Setupconn.
%
%    Setupconn is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Setupconn is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with Setupconn.  If not, see
%    <http://www.gnu.org/licenses/>.

%% This function sets up the connections given a trial
%

% This is setting up connections between the Type layer and Binding pool.
model.type_weight = zeros(parameter.type_size,parameter.bp_size);
model.type_2_weight = zeros(parameter.type_2_size,parameter.bp_size);

% if no similarity of connections, then the type to bp overlap will be random
type_weight_prop = ceil(parameter.type_conn*parameter.bp_size);
type_2_weight_prop = ceil(parameter.type_2_conn*parameter.bp_size);

% proportion of type to bp connections not shared between types
independent_type_1_weight_prop = ceil(parameter.type_conn * parameter.bp_size * (1-parameter.type_1_overlap));

% proportion of type to bp connections shared between types
overlap_type_1_weight_prop = ceil(parameter.type_conn * parameter.bp_size * parameter.type_1_overlap);

% proportion of type to bp connections not shared between types
independent_type_2_weight_prop = ceil(parameter.type_conn * parameter.bp_size * (1-parameter.type_2_overlap));

% proportion of type to bp connections shared between types
overlap_type_2_weight_prop = ceil(parameter.type_conn * parameter.bp_size * parameter.type_2_overlap);


% For each type node, this sets up the initial connections
for i = 1:parameter.type_size
    
    b = zeros(parameter.bp_size,1);
    a = randperm(parameter.bp_size);
    
    if parameter.similar_type_1_connections
        b(a(1:independent_type_1_weight_prop)) = 1;
    elseif parameter.fully_random_connectivity
        for j = 1:parameter.bp_size
            
            if rand < parameter.type_conn
                b(j) = 1;
            end
        end
    else
        b(a(1:type_weight_prop)) = 1;
    end
    
    model.type_weight(i,:) = b;
end




% Setting up the connection weights for type layer 2
for i = 1:parameter.type_2_size
    
    b = zeros(parameter.bp_size,1);
    a = randperm(parameter.bp_size);
    b(a(1:type_2_weight_prop)) = 1;
    
    if parameter.similar_type_2_connections
        b(a(1:independent_type_2_weight_prop)) = 1;
        
    else
        b(a(1:type_2_weight_prop)) = 1;
    end
    
    
    model.type_2_weight(i,:) = b;
end

% When similar connections is active, then this sets up the
if parameter.similar_type_1_connections
    
    bps = [];
    bp = [];
    for(conn = 1:overlap_type_1_weight_prop)
        
        % this goes through each type node
        for(t = randperm(parameter.type_size))
            
            % this will either 'hit' the left or right proximal type
            if(rand > .5)
                whichbuddy = 1;
            else
                whichbuddy = -1;
            end
            
            % looking at the neighbor will change if it is either the max
            % or min of the type space
            whichbuddy = t + whichbuddy;
            if(whichbuddy > parameter.type_size)  %wrap around
                whichbuddy = whichbuddy - parameter.type_size;
            end
            if(whichbuddy < 1)
                whichbuddy = whichbuddy + parameter.type_size;
            end
            
            % Find all active connections
            bps = find(model.type_weight(whichbuddy,:)==1);
            % Randomly select one of these connections
            bp =  randi(length(bps));
            while(model.type_weight(t,bps(bp)) == 1)
                bp =  randi(length(bps));
            end
            % Now, activate that connection in the buddy
            
            
            model.type_weight(t,bps(bp)) = 1;
            
        end
        
    end
    % Similar_check(model,parameter)
end

% When similar connections is active, then this sets up the
if parameter.similar_type_2_connections
    
    bps = [];
    bp = [];
    for(conn = 1:overlap_type_2_weight_prop)
        
        % this goes through each type node
        for(t = randperm(parameter.type_2_size))
            
            % this will either 'hit' the left or right proximal type
            if(rand > .5)
                whichbuddy = 1;
            else
                whichbuddy = -1;
            end
            
            % looking at the neighbor will change if it is either the max
            % or min of the type space
            whichbuddy = t + whichbuddy;
            if(whichbuddy > parameter.type_2_size)  %wrap around
                whichbuddy = whichbuddy - parameter.type_2_size;
            end
            if(whichbuddy < 1)
                whichbuddy = whichbuddy + parameter.type_2_size;
            end
            
            % Find all active connections
            bps = find(model.type_2_weight(whichbuddy,:)==1);
            % Randomly select one of these connections
            bp =  randi(length(bps));
            while(model.type_2_weight(t,bps(bp)) == 1)
                bp =  randi(length(bps));
            end
            % Now, activate that connection in the buddy
            
            
            model.type_2_weight(t,bps(bp)) = 1;
            
        end
        
    end
    % Similar_check(model,parameter)
end

% This is setting up connections between the Token layer and Binding pool.
token_weight = zeros(1,parameter.bp_size);
token_weight(1:parameter.bp_size) = 0;

% Determining the proportion of overlap between token connections to the
% binding pool
token_weight_prop = ceil(parameter.token_conn * parameter.bp_size);

for token = 1:parameter.token
    
    
    % This code is used instead (which is the exact same as the setup
    % for selecting type connections) if the token connections arent
    % fixed.
    b = zeros(parameter.bp_size,1);
    a = randperm(parameter.bp_size);
    
    if parameter.fully_random_connectivity
        for j = 1:parameter.bp_size
            
            if rand < parameter.token_conn
                b(j) = 1;
            end
        end
    else
        b(a(1:token_weight_prop)) = 1;
    end
    
    token_weight(token,:) = b;
    
    
end

model.token_weight = token_weight;
model.bpnodes = zeros(1,parameter.bp_size);

end

