function parameter = setParameters

%    This file is part of setParameters.
%
%    setParameters is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    setParameters is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with setParameters.  If not, see
%    <http://www.gnu.org/licenses/>.

%% This function sets up the parameters, as implied by the name of the
% function

% Number of trials
parameter.trialcount = 1000;

% Proportion of connections between the Type layers and Binding pool.
parameter.type_conn = .45;
parameter.type_2_conn = .45;
% The number of type nodes in the Type layers
parameter.type_size =  10;
parameter.type_2_size = 10;

% Size of the binding pool
parameter.bp_size = 800;

% Range of degree values
parameter.sensory_space = 360;

% The amount of overlap between token connections in the Binding pool
parameter.type_1_overlap = .3; % The parameter forces similar connections between proximal type nodes, creating similarity matrix.
parameter.type_2_overlap = 0;

% The amount of token nodes in the Token layer. Right now, this has been
% set to 8. However, setsize <= token.
parameter.token = 8;

% Proportion of connections between the tokens and binding pool
parameter.token_conn = .45;

% The number of stimuli the model is simulating. In this case, there will
% be 1 simulation of load 1, 2, 4, and 6.
parameter.setsize = [5 6];

% Sets the presented items to nonrandom
parameter.fixed_item_space = 0;
parameter.fixed_item_distance = 0; % If this is 0, then items are 360/load, otherwise, they are 360/fixed_item_distance. 

% Turn on confidence. This will only work with continuous report
parameter.confidence = 0;

% Defines the min and max of the uniform range of drawing capacity
parameter.capacitybottom = 2;
parameter.capacitytop = 7;

% This one refers to the similarity of connections between
% proximal type nodes.
parameter.similar_type_1_connections = 1;
parameter.similar_type_2_connections = 0;

% Determines whether or not the retrieved token is significantly different
% from the rest. If not exceed, the model effectively 'guesses'
parameter.token_individuation_threshold = .016;
%parameter.token_individuation_threshold = 0;

%% CONTINUOUS REPORT PARAMETERS
parameter.continuous_report = 0;

%% CHANGE DETECTION PARAMETERS
parameter.change_detection = 0;
parameter.changed_items = [1 1 1 1]; % This parameter determines how many items are changing per set size. The index is organized by set size. The first value must be 1. 

parameter.binding_items = 0; % This parameter is used to simulate binding switches such as Treisman et al. 2002
parameter.binding_experiment = 0; % This also needs to be turned on when simulating binding

parameter.probe_items = [2 4 6 8]; % This parameter determines the amount of items present during the second array. Currently, it is a whole display. It can be changed to a single display with ones(1,8)
parameter.scatter = 0; % Plot the relationship between correct rejections and false alarms and hits and misses.

% Single changed item
if max(parameter.changed_items) == 1
    parameter.length_threshold = [0.09]; % This parameter determines the y-intercept of the length threshold
    parameter.length_threshold_variable = [0.005]; % This parameter determines the linear slope change of the length threshold as a function of set size
    parameter.deviation_threshold = [.16]; % This parameter determines the y-intercept of the deviaion threshold
    parameter.deviation_threshold_variable = [.038]; % This parameter determines the linear slope change of the deviation threshold as a function of set size
%     
%     
%     parameter.length_threshold = [0.08]; % This parameter determines the y-intercept of the length threshold
%     parameter.length_threshold_variable = [0.008]; % This parameter determines the linear slope change of the length threshold as a function of set size
%     parameter.deviation_threshold = [.08]; % This parameter determines the y-intercept of the deviaion threshold
%     parameter.deviation_threshold_variable = [.04]; % This parameter determines the linear slope change of the deviation threshold as a function of set size
%     
    
    
else % Multiple changed item. These thresholds do not represent a 'best fit'.
    parameter.length_threshold = [0.075];
    parameter.length_threshold_variable = [0];
    parameter.deviation_threshold = [.15]; 
    parameter.deviation_threshold_variable = [.04];
end

%% PLOTTING PARAMETERS
parameter.plot_Model_sim =1; % Plot the model simulations

% If this is set to 0, then nothing will happen. Otherwise, this will fix
% token 2 to a specific degree value. Token 1 is always set to 180. If this
% is a vector, then column degree values will be fixed for that number of
% tokens. This is specific to Figures 10 and 14.
parameter.magnet_tokens = 0;
parameter.plot_hists = 0;

parameter.progress_bar = 0;

parameter.fixed_target_item = 0;

parameter.prob_of_change_trial = .50;

parameter.MCMC = 0;

parameter.jumps = 0;

parameter.no_type_cue = 0;

parameter.cue_items = 0;  %cueing items to prefer encoding, by encoding twice
parameter.cue_whichitem = [1];   %which item to encode

parameter.directed_forgetting = 0;

parameter.plot_retrieved_types = 0;

% FOR CHANGE DETECTION SIM OF Sims Jacobs & Knill 2012
parameter.fixed_variance = 0;
parameter.variance = [ 120 90 45 20 5 -5 -20 -45 -90 -120];

%restrict the range of selected encoding items to -n + n
parameter.reduced_variance = 0;
parameter.reduced_variance_size = 90;

% Determines if type 2 is used at all
parameter.type_layer_2_status = 1;

% normalizes bp after encoding
parameter.normalize_bp =1;

% Chance of connection being active is now dependent upon connections
% defined above
parameter.fully_random_connectivity = 0;

% Allows repeats in the presented items
% SPECIFICALLY FOR PRESENTED ITEMS 36, 72, 108,...
parameter.allow_repeats = 0;

% This determines how frequently the model will reintialize the connection
% weights. The number refers to the trial. In this case, if it is equal to
% 1, then the model will randomize the connections weights for each trial and for each set size.
parameter.new_setupconn = 100;

end

