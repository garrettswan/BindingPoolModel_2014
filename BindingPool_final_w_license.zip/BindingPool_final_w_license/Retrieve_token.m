%% This function checks the conjoining connections between the Type layer
% and the Token layer, then it summates the activation value for every
% Binding pool node connected to a specific token. This total value becomes
% the activation for that specific token node.

function [token_representation representation_2] = Retrieve_token(model,parameter,type1_layer,type2_layer)

%token_representation = zeros(parameter.token,1);
representation_2 =0;

a = 0;
b = 0;

%OPTIONS 1 and 3 below are UNTESTED

 if(type2_layer ==0) 
   token_representation =type1_layer' * model.type_1_weight.*model.bpnodes *model.token_weight' ;
 elseif (type1_layer ==0)
   token_representation =type2_layer' * model.type_2_weight.*model.bpnodes *model.token_weight' ;
 else
   token_representation =(type2_layer' * model.type_2_weight).*(type1_layer' * model.type_1_weight).*model.bpnodes *model.token_weight' ;
 
 end
   
   
   
   
   
   
   
   %    
% 
% for bpnode = 1:parameter.bp_size
% 
%     if(type2_layer ==0)   %retrieve token based on type_1
%         for(type =  1: length(type1_layer));
%             if model.type_weight(type,bpnode) == 1
%                 for token = 1:parameter.token  %retrieve this item
%                     token_input = type1_layer(type) * model.bpnodes(bpnode) * model.token_weight(token,bpnode);
%                     token_representation(token) = token_representation(token) + token_input;
%                 end
%             end
%         end
%         
%     elseif (type1_layer ==0)  % retrieve token based on type_2
%         for(type =  1: length(type2_layer));
%             if model.type_2_weight(type,bpnode) == 1
%                 for token = 1:parameter.token  %retrieve this item
%                     token_input = type2_layer(type) * model.bpnodes(bpnode) * model.token_weight(token,bpnode);
%                     token_representation(token) = token_representation(token) + token_input;
%                 end
%             end
%         end
%     else
%         for(type1 =  1: length(type1_layer))  %retrieve tokens based on both types
%             for(type2 =  1: length(type2_layer));
%                 if model.type_1_weight(type1,bpnode) == 1 & model.type_2_weight(type2,bpnode) == 1
%                     for token = 1:parameter.token  %retrieve this item
%                         token_input = type1_layer(type1) * type2_layer(type2) * model.bpnodes(bpnode) * model.token_weight(token,bpnode);
%                         token_representation(token) = token_representation(token) + token_input;
%                     end
%                 end
%             end
%         end
%         
%         
%     end
%     
% end

end



