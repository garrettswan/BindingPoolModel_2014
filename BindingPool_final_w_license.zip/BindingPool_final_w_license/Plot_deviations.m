function Plot_deviations(Model_sim,parameter)
%    This file is part of Plot_deviations.
%
%    Plot_deviations is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Plot_deviations is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with Plot_deviations.  If not, see
%    <http://www.gnu.org/licenses/>.

%% This function plots histograms for deviation

for load = parameter.setsize
    

    for trial = 1:parameter.trialcount

        deviations(trial) = rad2deg(Model_sim(load).trial_datastore.data(trial,randi(load)).raw_deviation);
        

        switch load
            case 1
                  sub_plot = 1;
             %   figure('Color',[1 1 1 ])
            case 2
                  sub_plot = 2;
             %   figure('Color',[1 1 1 ])
            case 4
                 sub_plot = 3;
             %   figure('Color',[1 1 1 ])
            case 6
                 sub_plot = 4;
             %   figure('Color',[1 1 1 ])
        end
        
        
            subplot(4,1,sub_plot);
        
        hist(deviations,[-180:5:180]);
        
        ylim([0 parameter.trialcount/4])
        
        set(gca,'Color',[1 1 1]);
        box off
        xlims = get(gca,'XLim');
        ylims = get(gca,'YLim');
        line(xlims,[ylims(2) ylims(2)],'Color','black');
        line([xlims(2) xlims(2)],ylims,'Color','black');
        
        set(gca,'Xtick',[-180 -90 0 90 180],'FontSize',12,'FontName','Arial');
        
        if load == 1
            title('Simulated Error Distributions','FontName','Arial','FontSize',16);
        end
        if load == 6
            xlabel('Responses relative to target','FontName','Arial','FontSize',16);
        end

    end
    
    
    deviations = [];
    
end

end

