function Model_sim = CD_Probe_display(trial_data,parameter,load)

%    This file is part of CD_Probe_display.
%
%    CD_Probe_display is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    CD_Probe_display is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with CD_Probe_display.  If not, see <http://www.gnu.org/licenses/>.

%% This function sets up the probe display in a change detection simulation

list_of_trials = randperm(parameter.trialcount);
change_trials = list_of_trials(1:ceil(parameter.trialcount*parameter.prob_of_change_trial));

for trial = 1:parameter.trialcount

    % First, must determine whether or not this is a change trial
    if max(trial == change_trials)

        list_of_items = Shuffle(1:load);

        changed_items = list_of_items(1:parameter.changed_items(load == parameter.setsize));

    else
        changed_items = zeros(1,parameter.changed_items(load == parameter.setsize));
    end

    % These two lines are specific to distal.
    fixed_index = 0;
    fixed_possible_items = Shuffle((load+1):length(trial_data(trial,1).presented_items));

    for token = 1:load

        % If this is a change trial...
        if max(token == changed_items)

            % Not simulating binding
            if parameter.binding_items == 0

                old_stimulus(trial,token) = rad2deg(trial_data(trial,token).target_radians);

                for i = 1:load
                    possible_items = Shuffle(parameter.changed_item_feature_range{load,i});
                    probe_display(trial,token) = possible_items(1);
                end

                %probe_display(trial,token) = randi(parameter.sensory_space);

                if parameter.fixed_item_space == 0 && parameter.fixed_variance == 0
                    % Probe display is random
                    while probe_display(trial,token) == old_stimulus(trial,token)
                        probe_display(trial,token) = randi(parameter.sensory_space);
                    end

                elseif parameter.fixed_item_space == 1 && parameter.fixed_variance == 0
                    % Similar to fixed_item space
                    fixed_index = fixed_index + 1;
                    probe_display(trial,token) = trial_data(trial,token).presented_items(fixed_possible_items(fixed_index));
                elseif parameter.fixed_variance

                    %                     if rand > .5
                    probe_display(trial,token) = old_stimulus(trial,token) + parameter.variance(randi(length(parameter.variance)));
                    %                     else
                    %                         probe_display(trial,token) = old_stimulus(trial,token) - parameter.variance(randi(length(parameter.variance)));
                    %                     end
                end
            else
                %Probe display uses same items, but 2 items switch
                %locations

                probe_display(trial,token) = rad2deg(trial_data(trial,changed_items(token~=changed_items)).target_radians);


            end

        else
            % Probe display is the same.
            probe_display(trial,token) = rad2deg(trial_data(trial,token).target_radians);

        end

                if probe_display(trial,token) > 360
                   probe_display(trial,token) = probe_display(trial,token) - 360;
        
                end
        
                if probe_display(trial,token) < 0
                    probe_display(trial,token) = probe_display(trial,token) + 360;
                end
        
%         if probe_display(trial,token) > 360
%             'over 360'
%         elseif probe_display(trial,token) < 0
%             'under zero'
%         end
        %
    end

    for token = 1:load

        retrieved_length = trial_data(trial,token).retrieved_length;

        deviation = (rad2deg(trial_data(trial,token).retrieved_location) - probe_display(trial,token));

        old_to_new = (rad2deg(trial_data(trial,token).target_radians) - probe_display(trial,token));




        if deviation < 0
            deviation = deviation + parameter.sensory_space;
        end

        if deviation > (parameter.sensory_space/2)
            deviation = parameter.sensory_space - deviation;
        end

        if old_to_new < 0
            old_to_new = old_to_new + parameter.sensory_space;
        end

        if old_to_new > (parameter.sensory_space/2)
            old_to_new = parameter.sensory_space - old_to_new;
        end

        % deviation is difference from presented to probe
        Model_sim.deviation(trial,token) = deviation/((parameter.sensory_space/2));

        Model_sim.retrieved_length(trial,token) = retrieved_length;
        Model_sim.changed_items(trial,1:parameter.changed_items(load==parameter.setsize)) = changed_items;

        % error is difference from retrieved to probe
        Model_sim.old_to_new(trial,token) = old_to_new;

    end

end

end