function RunAPP_data(trialcount,task,totalsubjects)

%    This file is part of RunAPP_data.
%
%    RunAPP_data is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Foobar is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.


%% RunAPP_data

%This script will run through each simulation and output the data as a
%graph.

% Note that in the plots, dotted lines are model simulation data and the
% full lines are data taken from Bays et al (2009) or from Keshvari et al
% (2013), depending on the task.

% The figure numbers refer to the figure number in the paper

% FIGURE 10
% Continuous report simulation
continuous_report_experiment = 0;

% FIGURE 9a and 9b
% Whole report change detection simulation
change_detection_experiment =1;

% FIGURE 14 and 15
% Run this simulation to output length and deviation histograms for various
% feature similarities.
dissimilarity_hists =0;

% FIGURE 13
% continuous report simulation with the results binned by the model's
% retrieval confidence
confidence_continuous_report_experiment = 0;
% FIGURE 11
% Run this simulation to see how the median of the response distribution is
% pulled by the separation of a second item
magnet_1_experiment = 0;

% FIGURE 16
% Run this simulation to see how the median of the response distribution is
% pulled by the relative separation of two items that maintain the same
% mean difference from the target item
magnet_2_experiment = 0;

% Page 21 
% Run this simulation to simulate an intentional forgetting paradigm in
% which the 2nd item is delete form memory after being stored in a
% continuous report task
directed_forgetting = 1;

% FIGURE 12
% This is a simulation of Sims et al (2012) in which the proportion of
% detecting a change is dependent upon the similarity of the presented
% stimuli
high_vs_low_similarity = 0;

% FIGURE 8
% Scatter plots of retrieved length and deviation for various set sizes
cd_scatters = 0;

% FIGURE 7
% Histogram of the retrieved deviation for various set sizes
retrieved_hists = 0;

if nargin == 0

task = [continuous_report_experiment ...
    change_detection_experiment ...
    dissimilarity_hists ...
    confidence_continuous_report_experiment ...
    magnet_1_experiment ...
    magnet_2_experiment ...
    directed_forgetting ...
    high_vs_low_similarity ...
    cd_scatters ...
    retrieved_hists];


    trialcount = 1000;
    totalsubjects = 5;
    
end


%% Continuous report
if task(1)
    tic
    %% Continuous report

    inputparams{1,1} = 'parameter.setsize';
    inputparams{1,2} = [1 2 4 6];

    inputparams{2,1} = 'parameter.continuous_report';
    inputparams{2,2} = [1];

    inputparams{3,1} = 'parameter.plot_Model_sim';
    inputparams{3,2} = [1];

    inputparams{4,1} = 'parameter.fixed_item_space';
    inputparams{4,2} = [0];

    inputparams{5,1} = 'parameter.confidence';
    inputparams{5,2} = [0];

    inputparams{6,1} = 'parameter.change_detection';
    inputparams{6,2} = [0];

    [continuous] = RunExperiment(inputparams,totalsubjects,1,1,trialcount);
    sprintf('Continuous report finished in %g seconds',toc)

end

%% Change detection
if task(2)
    tic

    inputparams{1,1} = 'parameter.setsize';
    inputparams{1,2} = [2 4 6 8];

    inputparams{2,1} = 'parameter.change_detection';
    inputparams{2,2} = [1];

    inputparams{3,1} = 'parameter.plot_Model_sim';
    inputparams{3,2} = [1];

    inputparams{4,1} = 'parameter.fixed_item_space';
    inputparams{4,2} = [0];

    inputparams{5,1} = 'parameter.changed_items';
    inputparams{5,2} = [ones(1,4)];

    inputparams{6,1} = 'parameter.display_items';
    inputparams{6,2} = [2 4 6 8];

    [change_detection] = RunExperiment(inputparams,totalsubjects,2,1,trialcount);
    sprintf('Change detection finished in %g seconds',toc)
end


%% Dissimilarity histograms
if task(3)
    tic
    
    sims = 6;
    
    figure
    
    for whichplot = 1:2

        for i = 1:sims
            
            inputparams{1,1} = 'parameter.setsize';
            setsizes = [4 4 4 4 4 1];
            inputparams{1,2} = setsizes(i);

            inputparams{2,1} = 'parameter.fixed_item_space';
            inputparams{2,2} = [1];

            inputparams{3,1} = 'parameter.fixed_item_distance';
            binsize = [4 6 12 24 360 0];
            inputparams{3,2} = binsize(i); % This determines bin size, 360/b2(i)

            inputparams{4,1} = 'parameter.plot_Model_sim';
            inputparams{4,2} = [0];

            specialtrialcount = [zeros(1,(sims-1))+trialcount trialcount*4];

            inputparams{5,1} = 'parameter.change_detection';
            inputparams{5,2} = [0];


            if whichplot == 1
                
                subplot(1,2,1)
                
                if i == sims
                    [dissimilarity] = RunExperiment(inputparams,totalsubjects,0,0,specialtrialcount(i));
                    
                    count = 0;
                    for sub = 1:totalsubjects
                        for trial = 1:specialtrialcount(i)
                            
                            count = count + 1;
                            deviations(count)  = rad2deg(dissimilarity.cr(sub).Model_sim(1).trial_datastore.data(trial,1).raw_deviation);

                        end
                    end
                    
                    
                    [n xout] = hist(deviations,[-180:5:180]);

                    plot(xout,n,'Color',[0 1 0],'LineWidth',3)
                    title('Dissimilarity')
                    hold on

                elseif i == (sims-1)
                    
                    [dissimilarity] = RunExperiment(inputparams,totalsubjects,0,0,specialtrialcount(i));

                    count = 0;
                    for sub = 1:totalsubjects
                        for trial = 1:specialtrialcount(i)
                            for token = 1:inputparams{1,2}
                            
                                count = count + 1;
                                deviations(count)  = rad2deg(dissimilarity.cr(sub).Model_sim(4).trial_datastore.data(trial,token).raw_deviation);
                            end
                        end
                    end
                    [n xout] = hist(deviations,[-180:5:180]);

                    plot(xout,n,'Color',[0 0 1],'LineWidth',3)
                    title('Dissimilarity')
                    hold on
                    
                else

                    [dissimilarity] = RunExperiment(inputparams,totalsubjects,0,0,specialtrialcount(i));

                    count = 0;
                    for sub = 1:totalsubjects
                        for trial = 1:specialtrialcount(i)
                            for token = 1:inputparams{1,2}
                            
                                count = count + 1;
                                deviations(count)  = rad2deg(dissimilarity.cr(sub).Model_sim(4).trial_datastore.data(trial,token).raw_deviation);
                            end
                        end
                    end
                    [n xout] = hist(deviations,[-180:5:180]);

                    plot(xout,n,'Color',[i*.2 0 0],'LineWidth',3)
                    title('Dissimilarity')
                    hold on


                end
            else
                
                subplot(1,2,2)
                
                 if i == sims
                    [dissimilarity] = RunExperiment(inputparams,totalsubjects,0,0,specialtrialcount(i));
                    
                    count = 0;
                    for sub = 1:totalsubjects
                        for trial = 1:specialtrialcount(i)
                            
                            count = count + 1;
                            retrieved_length(count)  = dissimilarity.cr(sub).Model_sim(1).trial_datastore.data(trial,1).retrieved_length;

                        end
                    end
                    [n xout] = hist(retrieved_length,[0:.014:1]);

                    plot(xout,n,'Color',[0 1 0],'LineWidth',3)
                    title('Retrieved Length')
                    hold on

                elseif i == (sims-1)
                    
                    [dissimilarity] = RunExperiment(inputparams,totalsubjects,0,0,specialtrialcount(i));

                    count = 0;
                    for sub = 1:totalsubjects
                        for trial = 1:specialtrialcount(i)
                            for token = 1:inputparams{1,2}
                            
                                count = count + 1;
                                retrieved_length(count)  = dissimilarity.cr(sub).Model_sim(4).trial_datastore.data(trial,token).retrieved_length;
                            end
                        end
                    end
                    [n xout] = hist(retrieved_length,[0:.014:1]);

                    plot(xout,n,'Color',[0 0 1],'LineWidth',3)
                    title('Retrieved Length')
                    hold on
                    
                else

                    [dissimilarity] = RunExperiment(inputparams,totalsubjects,0,0,specialtrialcount(i));

                    count = 0;
                    for sub = 1:totalsubjects
                        for trial = 1:specialtrialcount(i)
                            for token = 1:inputparams{1,2}
                            
                                count = count + 1;
                                retrieved_length(count)  = dissimilarity.cr(sub).Model_sim(4).trial_datastore.data(trial,token).retrieved_length;
                            end
                        end
                    end
                    [n xout] = hist(retrieved_length,[0:.014:1]);

                    plot(xout,n,'Color',[i*.2 0 0],'LineWidth',3)
                    title('Retrieved Length')
                    hold on


                 end
                
                 

            end
            
            
        end
        sprintf('Disimilarity simulation %d finished in %g seconds',i,toc)
    end

end

%% Confidence in continuous report
if task(4)
    tic

    inputparams{1,1} = 'parameter.setsize';
    inputparams{1,2} = [1 2 4 6];

    inputparams{2,1} = 'parameter.continuous_report';
    inputparams{2,2} = [1];

    inputparams{3,1} = 'parameter.plot_Model_sim';
    inputparams{3,2} = [1];

    inputparams{4,1} = 'parameter.change_detection';
    inputparams{4,2} = [0];

    inputparams{5,1} = 'parameter.confidence';
    inputparams{5,2} = [1];

    inputparams{6,1} = 'parameter.continuous_report';
    inputparams{6,2} = [1];

    [confidence] = RunExperiment(inputparams,totalsubjects,1,1,trialcount);
    sprintf('Confidence finished in %g seconds',toc);

end

%% Magnet simulation
if task(5)
    tic

    figure
    median_values = zeros(1,7);
    for i = 1:7

        inputparams{1,1} = 'parameter.setsize';
        inputparams{1,2} = [2];

        inputparams{2,1} = 'parameter.plot_Model_sim';
        inputparams{2,2} = [0];

        inputparams{3,1} = 'parameter.magnet_tokens';
        median_value = [0.001 18 36 54 72 90 108];
        inputparams{3,2} = median_value(i);

        inputparams{4,1} = 'parameter.continuous_report';
        inputparams{4,2} = [0];

        inputparams{5,1} = 'parameter.similar_connections';
        inputparams{5,2} = [1];

        inputparams{6,1} = 'parameter.change_detection';
        inputparams{6,2} = [0];


        [magnet_1(i)] = RunExperiment(inputparams,totalsubjects,0,0,trialcount);

        
        for sub = 1:totalsubjects
            
            count = 0;
            
            for trial = 1:trialcount
                
                    count = count + 1;
                    
                    med(count) =  rad2deg(magnet_1(i).cr(sub).Model_sim(2).trial_datastore.data(trial,1).raw_deviation);

            end
            
            median_val(sub) = median(med);
        end

        median_values(i) = mean(median_val);
        med_sd = std(median_val);

        med_std(i) = med_sd/sqrt(totalsubjects);

    end

    plot(median_value,median_values)
    errorbar(median_value,median_values,med_std)


    title('Magnet Median with 2 tokens')
    hold on
    sprintf('Magnet effect with 2 items finished in %g seconds',toc);

end

%% Magnet prediction
if task(6)
    tic

    figure
    median_values = zeros(1,4);
    for i = 1:4

        inputparams{1,1} = 'parameter.setsize';
        inputparams{1,2} = [3];

        inputparams{2,1} = 'parameter.plot_Model_sim';
        inputparams{2,2} = [0];

        inputparams{3,1} = 'parameter.magnet_tokens';
        median_vals_2 = [45 60 75 90; 135 120 105 90];
        inputparams{3,2} = median_vals_2(:,i);

        inputparams{4,1} = 'parameter.continuous_report';
        inputparams{4,2} = [0];

        inputparams{5,1} = 'parameter.similar_connections';
        inputparams{5,2} = [0];

        inputparams{6,1} = 'parameter.change_detection';
        inputparams{6,2} = [0];

        [magnet_2(i)] = RunExperiment(inputparams,totalsubjects,0,0,trialcount);

%         for sub = 1:totalsubjects
% 
%             median_val_2(sub) = magnet_2(i).cr(sub).Model_sim(3).magnet.med_deviation;
% 
%         end
        
        for sub = 1:totalsubjects
            
            count = 0;
            
            for trial = 1:trialcount
                
               count = count + 1;
                    
               med_2(count) =  rad2deg(magnet_2(i).cr(sub).Model_sim(3).trial_datastore.data(trial,1).raw_deviation);

            end
            
            median_val_2(sub) = median(med_2);
        end

        median_values_2(i) = mean(median_val_2);

        med_sd_2 = std(median_val_2);

        med_std_2(i) = med_sd_2/sqrt(totalsubjects);


    end

    x_vals = (median_vals_2(2,:)-median_vals_2(1,:));

    plot(x_vals,median_values_2)
    errorbar(x_vals,median_values_2,med_std_2)


    title('Magnet Median with 3 tokens')
    hold on
    sprintf('Magnet effect with 3 items finished in %g seconds',toc);

end

%% Directed forgetting
if task(7)
    tic
    figure
    
    vals = zeros(3,1000);
    
    for i = 1:3
        %% Continuous report

        inputparams{1,1} = 'parameter.setsize';
        whichsetsize = [1 2 2];
        inputparams{1,2} = whichsetsize(i);

        inputparams{2,1} = 'parameter.continuous_report';
        inputparams{2,2} = [1];

        inputparams{3,1} = 'parameter.plot_Model_sim';
        inputparams{3,2} = [1];

        inputparams{4,1} = 'parameter.directed_forgetting';
        if i == 3
            inputparams{4,2} = [1];
        else
            inputparams{4,2} = [0];
        end

        inputparams{5,1} = 'parameter.change_detection';
        inputparams{5,2} = [0];

        inputparams{6,1} = 'parameter.fixed_target_item';
        inputparams{6,2} = [1];

        [directed_forget] = RunExperiment(inputparams,totalsubjects,1,0,trialcount);
        sprintf('Continuous report finished in %g seconds',toc)

        sd(i) = directed_forget.continuous.error;

        count = 0;
        
        for trial = 1:trialcount
            for sub = 1:totalsubjects
                count = count + 1;
                vals(i,count) = rad2deg(directed_forget.cr(sub).Model_sim(whichsetsize(i)).trial_datastore.data(trial).raw_deviation);
            end
                       
        end

    end

    bar([1],sd(1),'b');
    hold on
    bar([2],sd(2),'r');
    bar([3],sd(3),'g');

    ylim([0 max(sd)+5])
    legend('Set Size 1','Set Size 2','Directed Forgetting')

%     [n1 xout1] = hist(vals(1,:),30);
%     [n2 xout2] = hist(vals(2,:),30);
%     [n3 xout3] = hist(vals(3,:),30);
%     
%     figure
%     plot(xout1,n1,'LineWidth',2,'Color','b');
%     xlim([-180 180]);
%     hold on
%     plot(xout2,n2,'LineWidth',2,'Color','r');
%     hold on
%     plot(xout3,n3,'LineWidth',2,'Color','g');
     
    sprintf('Directed forgetting finished in %g seconds',toc);

end


%% High versus low similarity
if task(8)
    tic

    for i = 1:2
        inputparams{1,1} = 'parameter.setsize';
        inputparams{1,2} = [2 4 6 8];

        inputparams{2,1} = 'parameter.plot_Model_sim';
        inputparams{2,2} = [0];

        inputparams{3,1} = 'parameter.change_detection';
        inputparams{3,2} = [1];

        inputparams{4,1} = 'parameter.continuous_report';
        inputparams{4,2} = [0];

        inputparams{5,1} = 'parameter.similar_connections';
        inputparams{5,2} = [1];

        inputparams{6,1} = 'parameter.fixed_variance';
        inputparams{6,2} = [1];

        inputparams{7,1} = 'parameter.reduced_variance';
        inputparams{7,2} = [i-1];

        inputparams{8,1} = 'parameter.MCMC';
        inputparams{8,2} = 0;

        [sims_simulation] = RunExperiment(inputparams,totalsubjects,2,0,trialcount);

        prop_change{i} = sims_simulation.change_detection.prop_change;

        clear sims_simulation

    end

    figure
    subplot(1,2,1)
    for i = 1:4

        for(bin = 2: 10)
            if(isnan(prop_change{1}(i,bin)))  %interpolate if there is a NAN

                interp = prop_change{1}(i,bin-1)+ prop_change{1}(i,bin+1);
                prop_change{1}(i,bin) = interp /2;
            end

        end

        plot(0:1:10,prop_change{1}(i,:),'LineWidth',2);
        hold on
        
    end
    title('Low Similarity')
    ylim([0 1])

    
    subplot(1,2,2)
    for i = 1:4
        
        for(bin = 2: 10)
            if(isnan(prop_change{2}(i,bin)))  %interpolate if there is a NAN

                interp = prop_change{2}(i,bin-1)+ prop_change{2}(i,bin+1);
                prop_change{2}(i,bin) = interp /2;
            end

        end
        
        plot(0:1:10,prop_change{2}(i,:),'LineWidth',2);
        hold on
    end
    title('High Similarity')
    ylim([0 1])



     sprintf('Sims simulation finished in %g seconds',toc);

end

%% Change Detection scatter plots
if task(9)
    
    tic

    totalsubjects = 1;

    inputparams{1,1} = 'parameter.setsize';
    inputparams{1,2} = [2 4 6 8];
        
    inputparams{2,1} = 'parameter.change_detection';
    inputparams{2,2} = [1];

    inputparams{3,1} = 'parameter.plot_Model_sim';
    inputparams{3,2} = [0];

    inputparams{4,1} = 'parameter.scatter';
    inputparams{4,2} = [1];

    inputparams{5,1} = 'parameter.fixed_item_space';
    inputparams{5,2} = [0];

    inputparams{6,1} = 'parameter.changed_items';
    inputparams{6,2} = [ones(1,4)];

    inputparams{7,1} = 'parameter.display_items';
    inputparams{7,2} = [2 4 6 8];

    [scatter_stuff] = RunExperiment(inputparams,totalsubjects,2,0,trialcount);
    sprintf('Scatters finished in %g seconds',toc)
    
end

%% Retrieved deviation histograms
if task(10)
    
    tic

    totalsubjects = 1;

    inputparams{1,1} = 'parameter.setsize';
    inputparams{1,2} = [1 2 4 6];
        
    inputparams{2,1} = 'parameter.change_detection';
    inputparams{2,2} = [0];

    inputparams{3,1} = 'parameter.plot_Model_sim';
    inputparams{3,2} = [0];

    inputparams{4,1} = 'parameter.plot_hists';
    inputparams{4,2} = [1];

    inputparams{5,1} = 'parameter.fixed_item_space';
    inputparams{5,2} = [0];

    inputparams{6,1} = 'parameter.confidence';
    inputparams{6,2} = [0];

    [retrieved_hist] = RunExperiment(inputparams,totalsubjects,0,0,trialcount);
    sprintf('Retrieved hists finished in %g seconds',toc)

end



