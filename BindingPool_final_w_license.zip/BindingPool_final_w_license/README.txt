
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Binding Pool model
by Garrett Swan and Brad Wyble
January 13th 2013


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Welcome to the Binding Pool model of visual working memory. The purpose of this README.txt is to 
guide you through the steps required to simulate a variety of visual working memory tasks.

Step one.
Run EasyMode.m

Step two.
Determine how many trials and the number of pseudo-subjects you would like to simulate.

Step three.
Determine whether you would like to run all simulations at once or just a single simulation

Step four.
Press the appropriate button and begin!

Thanks for your interest in the Binding Pool model.

For further information, please send an email to either gsp.swan@gmail.com or
bwyble@gmail.com

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Garrett Swan and Brad Wyble